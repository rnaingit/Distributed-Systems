package com.ub.pubsub.DistributedSystem.repository;

import com.ub.pubsub.DistributedSystem.model.SubscriberData;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface SubscriberRepository extends MongoRepository<SubscriberData,String> {

    SubscriberData findByUsername(String username);


}
