package com.ub.pubsub.DistributedSystem.controller;

import com.ub.pubsub.DistributedSystem.exception.ResourceNotFoundException;
import com.ub.pubsub.DistributedSystem.exception.UserServiceException;
import com.ub.pubsub.DistributedSystem.model.Login;
import com.ub.pubsub.DistributedSystem.model.User;
import com.ub.pubsub.DistributedSystem.repository.LoginRepository;
import com.ub.pubsub.DistributedSystem.repository.UserRepository;
import com.ub.pubsub.DistributedSystem.response.ResponseHandler;
import com.ub.pubsub.DistributedSystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

@RestController
@CrossOrigin
@RequestMapping("api/")
public class UserController {

    @Autowired
    UserRepository userRepository;

    @Autowired
    UserService userService;

    @Autowired
    LoginRepository loginRepository;

    @PostMapping("/add")
    public ResponseEntity<Object> createTutorial(@RequestBody User user) {
        try {
            boolean userExist = userService.userExists(user.getEmail());
            if(userExist){
                return ResponseHandler.generateResponse("User with email id already exists", HttpStatus.MULTI_STATUS, user.getEmail());
            }else {
                System.out.println("HERE");
                User _user = userRepository.save(new User(user.getUsername(), user.getEmail(), user.getPassword()));

                return ResponseHandler.generateResponse("Successfully added data!", HttpStatus.OK, _user);
            }
        } catch (Exception e) {
            return ResponseHandler.generateResponse(e.getMessage(), HttpStatus.MULTI_STATUS, null);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<Object> login(@RequestBody Login login){
        try{
            boolean loginExists = userService.loginExists(login.getEmail());
            if(loginExists){
                return ResponseHandler.generateResponse("Already Logged In", HttpStatus.MULTI_STATUS, login.getEmail());
            }else{
                boolean passwordValidater = userService.validateLoginPassword(login);
                Login _login = loginRepository.save(new Login(login.getEmail(),login.getPassword()));
                return ResponseHandler.generateResponse("Login Successful", HttpStatus.OK, _login);

            }
        }catch(Exception e){
            return ResponseHandler.generateResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR, null);
        }

    }

    @PostMapping("/logout")
    public ResponseEntity<Object> logout(@RequestBody Map<String, String> payload){
        loginRepository.deleteByEmail(payload.get("email"));

        return ResponseHandler.generateResponse("User Logged Out", HttpStatus.OK, null);
    }


    @PostMapping("/user")
    public ResponseEntity<?> getUser(@RequestBody Login login) throws ResourceNotFoundException, UserServiceException {
        try {
            User user = userRepository.findByEmail(login.getEmail());
            if (user == null) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND,"USER NOT FOUND");
            }else{
                if(user.getPassword().equals(login.getPassword())){
                    return new ResponseEntity<>(user,HttpStatus.OK);
                }else{
                    throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Incorrect Password");
                }
            }

        }catch (Exception e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"USER NOT FOUND");
        }
    }
}
