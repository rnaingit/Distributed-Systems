package com.ub.pubsub.DistributedSystem.controller;

import com.ub.pubsub.DistributedSystem.model.CovidData;
import com.ub.pubsub.DistributedSystem.model.Topics;
import com.ub.pubsub.DistributedSystem.model.User;
import com.ub.pubsub.DistributedSystem.repository.CovidRepository;
import com.ub.pubsub.DistributedSystem.repository.TopicRepository;
import com.ub.pubsub.DistributedSystem.response.ResponseHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClientException;

import java.io.IOException;


@RestController
@CrossOrigin
@RequestMapping("api/covid")
public class CovidDataController {

    @Autowired
    TopicRepository topicRepository;
    @Autowired
    CovidRepository covidRepository;
    @PostMapping("/add")
    public ResponseEntity<Object> addCovidData(@RequestBody CovidData covidData) {
        try {

                System.out.println("Inside Covid Controller");
                CovidData temp = covidRepository.findByState(covidData.getState());
                if(temp!=null){
                    covidRepository.delete(temp);
                    Topics topic = topicRepository.findByState(covidData.getState());
                    if(topic!=null){
                        topicRepository.delete(topic);
                    }
/*                    if(t!=null) {
                        topicRepository.delete(t);
                    }*/
                }
                topicRepository.save(new Topics(covidData.getState()));
                covidRepository.save(covidData);

                return ResponseHandler.generateResponse("Successfully added data!", HttpStatus.OK, "");

        } catch (Exception e) {
            return ResponseHandler.generateResponse(e.getMessage(), HttpStatus.MULTI_STATUS, null);
        }
    }


}
