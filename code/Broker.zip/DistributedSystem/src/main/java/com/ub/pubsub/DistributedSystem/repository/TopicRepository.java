package com.ub.pubsub.DistributedSystem.repository;

import com.ub.pubsub.DistributedSystem.model.Topics;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface TopicRepository extends MongoRepository<Topics,String> {

    Topics findByState(String state);
}
