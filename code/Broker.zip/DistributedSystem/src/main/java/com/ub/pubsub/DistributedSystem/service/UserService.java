package com.ub.pubsub.DistributedSystem.service;

import com.ub.pubsub.DistributedSystem.model.Login;
import com.ub.pubsub.DistributedSystem.model.User;
import com.ub.pubsub.DistributedSystem.repository.LoginRepository;
import com.ub.pubsub.DistributedSystem.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    UserRepository userRepository;

    @Autowired
    LoginRepository loginRepository;

    public boolean userExists(String email){
        User user = userRepository.findByEmail(email);
        if(user==null){
            return false;
        }else{
            return true;
        }

    }

    public boolean loginExists(String email){
        Login login = loginRepository.findByEmail(email);
        if(login==null){
            return false;
        }else{
            return true;
        }

    }

    public boolean validateLoginPassword(Login login) {
        User user = userRepository.findByEmail(login.getEmail());
        if(user.getPassword().equals(login.getPassword())){
            return true;
        }
        return false;
    }
}
