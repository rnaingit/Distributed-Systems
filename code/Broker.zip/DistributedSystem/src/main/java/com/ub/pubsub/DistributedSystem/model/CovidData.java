package com.ub.pubsub.DistributedSystem.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "covidData")
public class CovidData {
    @Id
    private String id;

    private String state;

    private String activeCases;

    private String deaths;

    private String date;

    public CovidData(String state, String activeCases, String deaths, String date) {
        this.state = state;
        this.activeCases = activeCases;
        this.deaths = deaths;
        this.date = date;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getActiveCases() {
        return activeCases;
    }

    public void setActiveCases(String activeCases) {
        this.activeCases = activeCases;
    }

    public String getDeaths() {
        return deaths;
    }

    public void setDeaths(String deaths) {
        this.deaths = deaths;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
