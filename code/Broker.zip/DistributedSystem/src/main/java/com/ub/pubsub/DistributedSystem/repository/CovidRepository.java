package com.ub.pubsub.DistributedSystem.repository;

import com.ub.pubsub.DistributedSystem.model.CovidData;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CovidRepository extends MongoRepository<CovidData,String> {

    CovidData findByState(String state);
}
