package com.ub.pubsub.DistributedSystem.service;


import com.ub.pubsub.DistributedSystem.model.SubscriberData;
import com.ub.pubsub.DistributedSystem.model.User;
import com.ub.pubsub.DistributedSystem.repository.SubscriberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SubscriberService {

    @Autowired
    SubscriberRepository subscriberRepository;

    public boolean subscriberExists(String email){
        SubscriberData subscriberData = subscriberRepository.findByUsername(email);
        if(subscriberData==null){
            return false;
        }else{
            return true;
        }

    }
}
