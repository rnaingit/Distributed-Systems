package com.ub.pubsub.DistributedSystem.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Set;

@Document(collection = "topics")
public class Topics {

    @Id
    private String id;

    private String state;

    public Topics(String states) {
        this.state = state;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
