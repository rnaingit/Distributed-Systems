package com.ub.pubsub.DistributedSystem.controller;

import com.ub.pubsub.DistributedSystem.model.CovidData;
import com.ub.pubsub.DistributedSystem.model.SubscriberData;
import com.ub.pubsub.DistributedSystem.model.Topics;
import com.ub.pubsub.DistributedSystem.repository.TopicRepository;
import com.ub.pubsub.DistributedSystem.response.ResponseHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@RestController
@CrossOrigin
@RequestMapping("api/topics")
public class TopicController {

    @Autowired
    TopicRepository topicRepository;

    @GetMapping("/advertise")
    public ResponseEntity<Object> getSubscriberData(){
        try {
            List<Topics> covidTopics= new ArrayList<>();
            covidTopics = topicRepository.findAll();
            Set<Topics> set = new HashSet<>(covidTopics);
            return  ResponseHandler.generateResponse("Available Topics", HttpStatus.OK, covidTopics);
        } catch (Exception e) {
            return ResponseHandler.generateResponse(e.getMessage(), HttpStatus.MULTI_STATUS, null);
        }
    }
}
