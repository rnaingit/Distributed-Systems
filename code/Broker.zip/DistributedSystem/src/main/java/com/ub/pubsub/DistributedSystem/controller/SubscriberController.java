package com.ub.pubsub.DistributedSystem.controller;


import com.ub.pubsub.DistributedSystem.model.CovidData;
import com.ub.pubsub.DistributedSystem.model.SubscriberData;
import com.ub.pubsub.DistributedSystem.repository.CovidRepository;
import com.ub.pubsub.DistributedSystem.repository.SubscriberRepository;
import com.ub.pubsub.DistributedSystem.response.ResponseHandler;
import com.ub.pubsub.DistributedSystem.service.SubscriberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("api/subscriber")
public class SubscriberController {

    @Autowired
    SubscriberRepository subscriberRepository;

    @Autowired
    SubscriberService subscriberService;

    @Autowired
    CovidRepository covidRepository;
    @PostMapping("/subscribe")
    public ResponseEntity<Object> addSubscriberTopic(@RequestBody SubscriberData sub) {
        try {
            boolean subscriberExists = subscriberService.subscriberExists(sub.getUsername());
            if(subscriberExists){

                SubscriberData updateData = subscriberRepository.findByUsername(sub.getUsername());
                List<String> temp= updateData.getTopics();
                for(String s : sub.getTopics()){
                    if(!temp.contains(s)){
                        temp.add(s);
                    }
                }
                updateData.setTopics(temp);
                subscriberRepository.save(updateData);
                System.out.println("Data Updated");
                return ResponseHandler.generateResponse("Successfully added data!", HttpStatus.OK, updateData);
            }else {
                System.out.println("HERE");
                SubscriberData _subscriber = subscriberRepository.save(new SubscriberData(sub.getUsername(), sub.getTopics()));

                return ResponseHandler.generateResponse("Successfully added data!", HttpStatus.OK, _subscriber);
            }
        } catch (Exception e) {
            return ResponseHandler.generateResponse(e.getMessage(), HttpStatus.MULTI_STATUS, null);
        }
    }

    @PostMapping("/unsubscribe")
    public ResponseEntity<Object> deleteSubscriberTopic(@RequestBody SubscriberData sub) {
        try {
            boolean subscriberExists = subscriberService.subscriberExists(sub.getUsername());
            if(subscriberExists){
                SubscriberData updateData = subscriberRepository.findByUsername(sub.getUsername());
                List<String> temp= updateData.getTopics();
                for(String s : sub.getTopics()){
                    if(temp.contains(s)){
                        temp.remove(s);
                    }
                }
                updateData.setTopics(temp);
                subscriberRepository.save(updateData);
                System.out.println("Data Updated");
                return ResponseHandler.generateResponse("Successfully Updated data!", HttpStatus.OK, updateData);
            }else {

                return ResponseHandler.generateResponse("No User Exists", HttpStatus.NOT_FOUND, sub.getUsername());
            }
        } catch (Exception e) {
            return ResponseHandler.generateResponse(e.getMessage(), HttpStatus.MULTI_STATUS, null);
        }
    }

    @GetMapping("/subscriberData/{username}")
    public ResponseEntity<Object> getSubscriberData(@PathVariable(required=true,name="username") String username){
        try {
            List<CovidData>  covidData= new ArrayList<>();
            boolean subscriberExists = subscriberService.subscriberExists(username);
            if(subscriberExists){
                SubscriberData data = subscriberRepository.findByUsername(username);
                for(String s : data.getTopics()){
                    CovidData temp = covidRepository.findByState(s);
                    if(temp!=null) {
                        covidData.add(temp);
                    }
                }
                if(covidData.isEmpty()){
                    return ResponseHandler.generateResponse("No Data Present", HttpStatus.NOT_FOUND, username);
                }
                return ResponseHandler.generateResponse("Success", HttpStatus.OK, covidData );
            }else {

                return ResponseHandler.generateResponse("No User Exists", HttpStatus.NOT_FOUND, username);
            }
        } catch (Exception e) {
            return ResponseHandler.generateResponse(e.getMessage(), HttpStatus.MULTI_STATUS, null);
        }
    }
}
