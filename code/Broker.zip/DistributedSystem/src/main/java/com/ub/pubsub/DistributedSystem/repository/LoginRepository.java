package com.ub.pubsub.DistributedSystem.repository;

import com.ub.pubsub.DistributedSystem.model.Login;
import com.ub.pubsub.DistributedSystem.model.User;
import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface LoginRepository extends MongoRepository<Login,String > {
    Login findByEmail(String email);

    @DeleteQuery
    void deleteByEmail(String email);
}
