package com.ub.pubsub.DistributedSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistributedSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
